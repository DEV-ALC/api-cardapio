import bcrypt from "bcryptjs";
import { D1Database } from '@cloudflare/workers-types';
import { gerarToken, validarToken } from './auth';
import { LoginBody, CadastroEmpresaBody, TokenPayload } from './types';

export interface Env {
  D1_BANCO: D1Database;
}

async function gerarHash(senha: string): Promise<string> {
  const hash = await bcrypt.hash(senha, 10); // assíncrono
  return hash; // <- isso é fundamental
}

// Comparar senha recebida com hash salvo no banco
async function validarSenha(senha: string, hash: string): Promise<boolean> {
  return await bcrypt.compare(senha, hash); // direto, não precisa gerar outro hash
}

export default {
  async fetch(request: Request, env: Env) {
    const url = new URL(request.url);

    // === CORS ===
    if (request.method === 'OPTIONS') {
      return new Response(null, {
        status: 204,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        },
      });
    }

    // ====================== LOGIN ======================
    if (url.pathname === '/login' && request.method === 'POST') {
      const body: LoginBody = await request.json();

      // Busca usuário pelo nome
      const res = await env.D1_BANCO
        .prepare("SELECT empresa, usuario, tipo, senha FROM usuario WHERE usuario = ?")
        .bind(body.usuario)
        .first<{ empresa: string; usuario: string; tipo: string; senha: string }>();

      if (!res) return new Response("Usuário ou senha incorretos", { status: 401 });

      // Valida senha com SHA-256
      const senhaValida = await validarSenha(body.senha, res.senha);
      if (!senhaValida) return new Response("Usuário ou senha incorretos", { status: 401 });

      // Gera token com usuario, empresa e tipo
      const token = await gerarToken({
        usuario: res.usuario,
        empresa: res.empresa,
        tipo: res.tipo as TokenPayload['tipo']
      });

      return new Response(JSON.stringify({
        token,
        usuario: res.usuario,
        empresa: res.empresa
      }), {
        status: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        }
      });
    }
		// ====================== GERAR HASH ======================
if (url.pathname === '/gerar-hash' && request.method === 'POST') {
  try {
    const { senha }: { senha: string } = await request.json();

    if (!senha) {
      return new Response(JSON.stringify({ erro: "Senha não fornecida" }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const hash = await gerarHash(senha);

    return new Response(JSON.stringify({ senha, hash }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err) {
    return new Response(JSON.stringify({ erro: "Falha ao gerar hash", detalhe: err }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}

    // ====================== ROTAS PROTEGIDAS ======================
    const authHeader = request.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response("Token faltando", { status: 401 });
    }

    const token = authHeader.split(' ')[1];
    const payload: TokenPayload | null = await validarToken(token);
    if (!payload) return new Response("Token inválido ou expirado", { status: 401 });

    // ====================== CADASTRAR EMPRESA ======================
    if (url.pathname === '/cadastrar-empresa' && request.method === 'POST') {
      if (payload.tipo !== 'softhouse' && payload.tipo !== 'admin') {
        return new Response("Permissão negada", { status: 403 });
      }

      const body: CadastroEmpresaBody = await request.json();
      const tokenGerado = "token-teste";
      const expira = new Date();
      expira.setFullYear(expira.getFullYear() + 1);

      await env.D1_BANCO
        .prepare("INSERT INTO empresa (empresa, nomeEmpresa, slug, token, tokenExpira, imagemId) VALUES (?, ?, ?, ?, ?, ?)")
        .bind(body.empresa, body.nomeEmpresa, body.slug, tokenGerado, expira.toISOString(), body.imagemId || null)
        .run();

      return new Response("Empresa cadastrada com sucesso!");
    }

    // ====================== LISTAR USUÁRIOS ======================
    if (url.pathname === '/usuarios' && request.method === 'GET') {
      if (payload.tipo !== 'softhouse' && payload.tipo !== 'admin') {
        return new Response("Permissão negada", { status: 403 });
      }

      const res = await env.D1_BANCO
        .prepare("SELECT empresa, usuario, tipo FROM usuario")
        .all<{ empresa: string; usuario: string; tipo: string }>();

      return new Response(JSON.stringify(res.results || []), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });
    }



    return new Response("Rota não encontrada", { status: 404 });
  }
};

export interface LoginBody {
  usuario: string;
  senha: string;
}

export interface CadastroEmpresaBody {
  empresa: string;
  nomeEmpresa: string;
  slug: string;
  imagemId?: string | null;
}

// TokenPayload só com uuid e tipo
export interface TokenPayload {
  usuario: string;
  empresa: string;
  tipo: 'admin' | 'softhouse';
}

